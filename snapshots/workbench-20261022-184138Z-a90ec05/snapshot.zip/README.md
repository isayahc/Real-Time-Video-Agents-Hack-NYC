# Workbench snapshot

- Created (UTC): 20261022-184138Z
- Source commit: `a90ec05b1ffc7019993003b3f722655f3ee8c836`
- PR: https://github.com/isayahc/Real-Time-Video-Agents-Hack-NYC/pull/49
- Integrated-workcell follow-up: https://github.com/isayahc/Real-Time-Video-Agents-Hack-NYC/issues/48
- Example run: `2b36990135d7406c8db35e9504221fce`

## Contents

- `source/`: committed source at the revision above, including documentation and tests.
- `runs/workbench/2b36990135d7406c8db35e9504221fce/`: source video, sampled evidence, extraction, design/costs,
  machine CAD, cached previews, scene/lab exports and available review artifacts.
- `evidence/`: available browser screenshots. Some screenshots demonstrate other example runs.
- `manifest.json`: file SHA-256 hashes, sizes, source revision and capture metadata.

## Current state and limitations

The example has seven generated machine assets. Step 8 stages them in a fixed lab using
semantic zoning, operation relationships and CAD footprints. It does NOT assemble an
integrated functioning machine: the vacuum tool is not attached to the robot wrist and
the camera mount/target remains unresolved. Placed counts do not establish assembly
readiness, robot reach, physical operation or safety. Issue #48 records the redesign.

Full source verification before snapshot: 163 tests and 10 subtests passed.
The latest GMI live credential checks returned HTTP 401; registered models are not proof
of current access. No fresh model calls were made to create this snapshot.

## Reopen

Portable `scene.oi.json` exports under the run's `scene/` and `lab/` attempt directories
can be opened in a compatible OpenIndustries installation. Their geometry is bundled.
The original run files and relative layout have been retained; some provenance records
contain original local absolute paths and historical process IDs, not active processes.

To use the source, follow `source/docs/video-workbench.md`, install its dependencies,
and configure Forma/OpenIndustries locally. From `source/`, set WORKBENCH_RUNS to the
absolute snapshot `runs/workbench` path and run `python -m protocol_pipeline.web`.
Use a copy of this snapshot if you intend to regenerate assets or edit the saved run.

Credentials, logs, temporary files, OpenCode response transcripts and session files are
excluded. Dependencies and external Forma/OpenIndustries repositories are not vendored.
