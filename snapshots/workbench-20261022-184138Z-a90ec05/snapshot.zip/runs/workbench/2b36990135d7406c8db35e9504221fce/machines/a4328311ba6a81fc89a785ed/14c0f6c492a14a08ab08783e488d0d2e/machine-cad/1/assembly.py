import json
from opencad import Part, Sketch
data = json.load(open('C:\\Users\\isaya\\Real-Time-Video-Agents-Hack-NYC\\runs\\workbench\\2b36990135d7406c8db35e9504221fce\\machines\\a4328311ba6a81fc89a785ed\\14c0f6c492a14a08ab08783e488d0d2e\\machine-cad\\1\\assembly.json', encoding="utf-8"))
from pathlib import Path
directory = Path('C:\\Users\\isaya\\Real-Time-Video-Agents-Hack-NYC\\runs\\workbench\\2b36990135d7406c8db35e9504221fce\\machines\\a4328311ba6a81fc89a785ed\\14c0f6c492a14a08ab08783e488d0d2e\\machine-cad\\1')
shapes = []
for item in data["parts"]:
    x,y,z = item["center_mm"]
    sx,sy,sz = item["size_mm"]
    kind,name = item["shape"],item["name"]
    if kind == "box":
        sketch = Sketch(plane="XY", origin=(0,0,z-sz/2), name=name+" profile")
        sketch.rect(sx,sy,origin=(x-sx/2,y-sy/2))
        shape = Part(name=name).extrude(sketch,depth=sz,name=name)
    elif kind == "cylinder_x":
        sketch = Sketch(plane="YZ", origin=(x-sx/2,0,0), name=name+" profile")
        sketch.circle(min(sy,sz)/2,center=(y,z))
        shape = Part(name=name).extrude(sketch,depth=sx,name=name)
    elif kind == "cylinder_y":
        sketch = Sketch(plane="XZ", origin=(0,y+sy/2,0), name=name+" profile")
        sketch.circle(min(sx,sz)/2,center=(x,z))
        shape = Part(name=name).extrude(sketch,depth=sy,name=name)
    else:
        sketch = Sketch(plane="XY", origin=(0,0,z-sz/2), name=name+" profile")
        sketch.circle(min(sx,sy)/2,center=(x,y))
        shape = Part(name=name).extrude(sketch,depth=sz,name=name)
    shapes.append(shape)
    index = len(shapes)-1
    shape.export_step(str(directory / ("part-"+str(index)+".step")))
    shape.export_stl(str(directory / ("part-"+str(index)+".stl")))
model = shapes[-1]
model
