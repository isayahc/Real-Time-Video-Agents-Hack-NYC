# Transfer Copper Substrates from Beige Pad to Container

**Explicitly supplied plan; acceptance and physical performance remain unverified.**

Functional unit: One copper square substrate transferred to container

Boundary: From initial placement on beige pad to placement inside transparent container; includes use of tweezers and human handling actions observed within video frames.

| Operation | Phase / frequency | Candidate equipment |
| --- | --- | --- |
| op_transfer_1: Move first copper substrate into container | processing / once | obj_container; obj_tweezers |
| op_remove_2: Remove second copper substrate from pad | preparation / once | obj_tweezers |

## Resource results

| Metric | Value | Basis |
| --- | --- | --- |
| labor_s_per_accepted | unknown | unknown |
| electricity_wh_per_accepted | unknown | unknown |
| stock_g_per_accepted | unknown | unknown |
| recoverable_scrap_g_per_accepted | unknown | unknown |
| unrecovered_waste_g_per_accepted | unknown | unknown |
| accepted_outputs_per_hour | unknown | unknown |
| accepted_fraction | unknown | unknown |
| total_cost_usd_per_batch | unknown | unknown |
| cost_usd_per_accepted | unknown | unknown |

## Acceptance checks

- First copper substrate is fully inside the container after transfer operation: Visual confirmation that obj_copper_1 is within the boundaries of obj_container in post-transfer frames.
- Second copper substrate is lifted off the beige pad: Visual confirmation from state change sc_copper_2 that obj_copper_2 is no longer in contact with obj_beige_pad.
- First substrate is transferred before the second is removed: Temporal alignment shows op_transfer_1 ends at 10.03s and op_remove_2 starts at same time, supporting sequential order hypothesis.

## Missing resource inputs

- accepted_count
- allocated_tooling_cost
- attempted_count
- consumables_cost
- consumed_stock_g
- elapsed_s
- electricity_rate
- electricity_wh
- facility_cost
- labor_s
- loaded_labor_rate
- maintenance_cost
- other_utilities_cost
- paid_coverage_cost
- recoverable_scrap_g
- recovery_credit
- stock_cost
- unrecovered_waste_g

## Limitations

- The final destination of the second copper square is not visible after it is lifted.
- Exact material composition of the substrates is inferred visually but not confirmed.
- No quantitative timing or force data available for transfer operations.
- Attended duration for each operation is unknown due to lack of continuous tracking beyond start and end of actions.
- Automatically extracted candidate; structural grounding is not semantic verification.
- Provider: nebius; live model inference

No durations, resource quantities or acceptance outcomes are inferred from operation names or equipment. Preparation ranges are not summed; concurrency and task overlap require review.
